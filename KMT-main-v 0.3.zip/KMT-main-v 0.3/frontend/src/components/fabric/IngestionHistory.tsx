import React, { useEffect, useState } from "react";
import { getIngestionHistory, IngestionHistoryRecord } from "../../api/analyticsApi";
import { LoadingSpinner } from "../../components/common/LoadingSpinner";
import { EmptyState } from "../../components/common/EmptyState";
import {
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  ChevronDownIcon,
  ChevronUpIcon,
} from "@heroicons/react/24/outline";

interface IngestionHistoryProps {
  fabricId: string;
}

export const IngestionHistory: React.FC<IngestionHistoryProps> = ({ fabricId }) => {
  const [history, setHistory] = useState<IngestionHistoryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    loadHistory();
  }, [fabricId]);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const data = await getIngestionHistory(fabricId);
      setHistory(data);
    } catch (err) {
      console.error("Failed to load ingestion history", err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (history.length === 0) {
    return (
      <EmptyState
        icon={<ClockIcon className="w-16 h-16" />}
        title="No Ingestion History"
        message="This fabric hasn't been built yet."
      />
    );
  }

  return (
    <div className="space-y-3">
      {history.map((record) => (
        <IngestionRecord
          key={record.id}
          record={record}
          isExpanded={expandedId === record.id}
          onToggle={() => setExpandedId(expandedId === record.id ? null : record.id)}
        />
      ))}
    </div>
  );
};

interface IngestionRecordProps {
  record: IngestionHistoryRecord;
  isExpanded: boolean;
  onToggle: () => void;
}

const IngestionRecord: React.FC<IngestionRecordProps> = ({
  record,
  isExpanded,
  onToggle,
}) => {
  const getStatusIcon = () => {
    switch (record.status) {
      case "completed":
        return <CheckCircleIcon className="w-5 h-5 text-green-400" />;
      case "failed":
        return <XCircleIcon className="w-5 h-5 text-red-400" />;
      default:
        return <ClockIcon className="w-5 h-5 text-blue-400" />;
    }
  };

  const getStatusColor = () => {
    switch (record.status) {
      case "completed":
        return "text-green-400";
      case "failed":
        return "text-red-400";
      default:
        return "text-blue-400";
    }
  };

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return "N/A";
    if (seconds < 60) return `${seconds}s`;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="card p-4">
      <div
        className="flex items-center justify-between cursor-pointer"
        onClick={onToggle}
      >
        <div className="flex items-center space-x-3 flex-1">
          {getStatusIcon()}
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <span className={`font-medium ${getStatusColor()}`}>
                {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-sm text-slate-400">
                {new Date(record.startedAt).toLocaleString()}
              </span>
            </div>
            <div className="text-sm text-slate-400 mt-1">
              {record.documentsIngested} documents · {record.chunksCreated} chunks
              {record.durationSeconds && (
                <span> · {formatDuration(record.durationSeconds)}</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          {record.sourcesIngested && record.sourcesIngested.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {record.sourcesIngested.map((source) => (
                <span
                  key={source}
                  className="text-xs px-2 py-1 bg-slate-700 text-slate-300 rounded"
                >
                  {source}
                </span>
              ))}
            </div>
          )}
          {isExpanded ? (
            <ChevronUpIcon className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronDownIcon className="w-5 h-5 text-slate-400" />
          )}
        </div>
      </div>

      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-slate-700 space-y-4">
          {/* Details */}
          {record.details && Object.keys(record.details).length > 0 && (
            <div>
              <div className="text-sm font-medium text-slate-300 mb-2">Details:</div>
              <div className="bg-slate-800 p-3 rounded text-xs font-mono text-slate-400 overflow-x-auto">
                <pre>{JSON.stringify(record.details, null, 2)}</pre>
              </div>
            </div>
          )}

          {/* Error Message */}
          {record.errorMessage && (
            <div>
              <div className="text-sm font-medium text-red-400 mb-2">Error:</div>
              <div className="bg-red-900/20 border border-red-800 p-3 rounded text-sm text-red-300">
                {record.errorMessage}
              </div>
            </div>
          )}

          {/* Timestamps */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-slate-400">Started:</div>
              <div className="text-slate-200">
                {new Date(record.startedAt).toLocaleString()}
              </div>
            </div>
            {record.completedAt && (
              <div>
                <div className="text-slate-400">Completed:</div>
                <div className="text-slate-200">
                  {new Date(record.completedAt).toLocaleString()}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

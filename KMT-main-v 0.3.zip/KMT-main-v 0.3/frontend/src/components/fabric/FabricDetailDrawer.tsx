import React, { useState, useEffect } from "react";
import { Fabric } from "../../types/fabric";
import { getFabricDetailedStats, DetailedStats } from "../../api/analyticsApi";
import { LoadingSpinner } from "../../components/common/LoadingSpinner";
import { IngestionHistory } from "../../components/fabric/IngestionHistory";
import { KnowledgeGraphView } from "../../components/fabric/KnowledgeGraphView";
import { XMarkIcon } from "@heroicons/react/24/outline";

interface FabricDetailDrawerProps {
  fabric: Fabric | null;
  isOpen: boolean;
  onClose: () => void;
}

type TabType = "overview" | "statistics" | "history" | "graph";

export const FabricDetailDrawer: React.FC<FabricDetailDrawerProps> = ({
  fabric,
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>("overview");
  const [detailedStats, setDetailedStats] = useState<DetailedStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(false);

  useEffect(() => {
    if (fabric && activeTab === "statistics") {
      loadDetailedStats();
    }
  }, [fabric, activeTab]);

  const loadDetailedStats = async () => {
    if (!fabric) return;
    setLoadingStats(true);
    try {
      const stats = await getFabricDetailedStats(fabric.id);
      setDetailedStats(stats);
    } catch (err) {
      console.error("Failed to load detailed stats", err);
    } finally {
      setLoadingStats(false);
    }
  };

  if (!isOpen || !fabric) return null;

  const tabs: { id: TabType; label: string }[] = [
    { id: "overview", label: "Overview" },
    { id: "statistics", label: "Statistics" },
    { id: "history", label: "Ingestion History" },
    { id: "graph", label: "Knowledge Graph" },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="absolute right-0 top-0 h-full w-full md:w-3/4 lg:w-2/3 bg-slate-900 shadow-xl overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900 border-b border-slate-800 p-6 z-10">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-slate-100">{fabric.name}</h2>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white transition-colors"
            >
              <XMarkIcon className="w-6 h-6" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex space-x-1 bg-slate-800 p-1 rounded-lg">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? "bg-brand-600 text-white"
                    : "text-slate-400 hover:text-white hover:bg-slate-700"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === "overview" && <OverviewTab fabric={fabric} />}
          {activeTab === "statistics" && (
            <StatisticsTab
              fabric={fabric}
              detailedStats={detailedStats}
              loading={loadingStats}
            />
          )}
          {activeTab === "history" && <IngestionHistory fabricId={fabric.id} />}
          {activeTab === "graph" && <KnowledgeGraphView fabricId={fabric.id} />}
        </div>
      </div>
    </div>
  );
};

const OverviewTab: React.FC<{ fabric: Fabric }> = ({ fabric }) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-2">Description</h3>
        <p className="text-slate-400">{fabric.description || "No description"}</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-2">Domain</h3>
        <p className="text-slate-400">{fabric.domain}</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-2">Status</h3>
        <span
          className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
            fabric.status === "Ready"
              ? "bg-green-600 text-white"
              : fabric.status === "Error"
              ? "bg-red-600 text-white"
              : "bg-blue-600 text-white"
          }`}
        >
          {fabric.status}
        </span>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-2">Quick Stats</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="card p-4">
            <div className="text-sm text-slate-400">Documents</div>
            <div className="text-2xl font-bold text-slate-100">
              {fabric.documentsCount || 0}
            </div>
          </div>
          <div className="card p-4">
            <div className="text-sm text-slate-400">Chunks</div>
            <div className="text-2xl font-bold text-slate-100">
              {fabric.chunksCount || 0}
            </div>
          </div>
          <div className="card p-4">
            <div className="text-sm text-slate-400">Graph Nodes</div>
            <div className="text-2xl font-bold text-slate-100">
              {fabric.graphNodes || 0}
            </div>
          </div>
          <div className="card p-4">
            <div className="text-sm text-slate-400">Graph Edges</div>
            <div className="text-2xl font-bold text-slate-100">
              {fabric.graphEdges || 0}
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-2">Sources</h3>
        <div className="space-y-2">
          {fabric.sources?.serviceNow?.enabled && (
            <div className="card p-3">
              <div className="font-medium text-slate-100">ServiceNow</div>
              <div className="text-sm text-slate-400">
                {fabric.sources.serviceNow.tables?.join(", ")}
              </div>
            </div>
          )}
          {fabric.sources?.uploads?.fileNames && fabric.sources.uploads.fileNames.length > 0 && (
            <div className="card p-3">
              <div className="font-medium text-slate-100">
                Uploaded Files ({fabric.sources.uploads.fileNames.length})
              </div>
              <div className="text-sm text-slate-400">
                {fabric.sources.uploads.fileNames.slice(0, 3).join(", ")}
                {fabric.sources.uploads.fileNames.length > 3 && "..."}
              </div>
            </div>
          )}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-2">Timestamps</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-400">Created:</span>
            <span className="text-slate-200">
              {new Date(fabric.createdAt).toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Updated:</span>
            <span className="text-slate-200">
              {new Date(fabric.updatedAt).toLocaleString()}
            </span>
          </div>
          {fabric.lastSyncedAt && (
            <div className="flex justify-between">
              <span className="text-slate-400">Last Synced:</span>
              <span className="text-slate-200">
                {new Date(fabric.lastSyncedAt).toLocaleString()}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const StatisticsTab: React.FC<{
  fabric: Fabric;
  detailedStats: DetailedStats | null;
  loading: boolean;
}> = ({ fabric, detailedStats, loading }) => {
  if (loading) {
    return <LoadingSpinner />;
  }

  if (!detailedStats) {
    return <div className="text-slate-400">No statistics available</div>;
  }

  const { stored, realtime, files } = detailedStats;

  return (
    <div className="space-y-6">
      {/* Storage Stats */}
      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-4">Storage Statistics</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="card p-4">
            <div className="text-sm text-slate-400">Documents</div>
            <div className="text-2xl font-bold text-slate-100">{stored.documentsCount}</div>
          </div>
          <div className="card p-4">
            <div className="text-sm text-slate-400">Chunks (Stored)</div>
            <div className="text-2xl font-bold text-slate-100">{stored.chunksCount}</div>
          </div>
          <div className="card p-4">
            <div className="text-sm text-slate-400">Chunks (ChromaDB)</div>
            <div className="text-2xl font-bold text-slate-100">{realtime.chunksInChromaDB}</div>
          </div>
          <div className="card p-4">
            <div className="text-sm text-slate-400">Validation</div>
            <div className="text-2xl font-bold">
              {realtime.matchesStored ? (
                <span className="text-green-400">✓</span>
              ) : (
                <span className="text-red-400">✗</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Source Breakdown */}
      {stored.sourceBreakdown && Object.keys(stored.sourceBreakdown).length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-slate-100 mb-4">Source Breakdown</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(stored.sourceBreakdown).map(([source, count]) => (
              <div key={source} className="card p-4">
                <div className="text-sm text-slate-400 capitalize">{source}</div>
                <div className="text-2xl font-bold text-slate-100">{count as number}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Ingestion Stats */}
      {stored.ingestionStats && Object.keys(stored.ingestionStats).length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-slate-100 mb-4">Ingestion Details</h3>
          <div className="card p-4 bg-slate-800">
            <pre className="text-xs text-slate-300 overflow-x-auto">
              {JSON.stringify(stored.ingestionStats, null, 2)}
            </pre>
          </div>
        </div>
      )}

      {/* File List */}
      {files && files.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-slate-100 mb-4">
            Files ({files.length})
          </h3>
          <div className="space-y-2">
            {files.map((file: any) => (
              <div key={file.id} className="card p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-slate-100">{file.sourceName}</div>
                    <div className="text-sm text-slate-400">
                      {file.documentCount} documents · {file.chunkCount} chunks
                    </div>
                  </div>
                  <div className="text-xs text-slate-500">{file.sourceType}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

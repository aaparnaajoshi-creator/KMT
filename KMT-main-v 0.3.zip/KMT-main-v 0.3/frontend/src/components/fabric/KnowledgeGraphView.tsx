import React, { useEffect, useState, useRef } from "react";
import { getKnowledgeGraph, getNodeDetails, KnowledgeGraph, GraphNode, NodeDetails } from "../../api/analyticsApi";
import { LoadingSpinner } from "../../components/common/LoadingSpinner";
import { EmptyState } from "../../components/common/EmptyState";
import { CubeTransparentIcon, XMarkIcon } from "@heroicons/react/24/outline";

interface KnowledgeGraphViewProps {
  fabricId: string;
}

export const KnowledgeGraphView: React.FC<KnowledgeGraphViewProps> = ({ fabricId }) => {
  const [graph, setGraph] = useState<KnowledgeGraph | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedNode, setSelectedNode] = useState<NodeDetails | null>(null);
  const [nodeFilter, setNodeFilter] = useState<string>("all");
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    loadGraph();
  }, [fabricId]);

  useEffect(() => {
    if (graph && canvasRef.current) {
      drawGraph();
    }
  }, [graph, nodeFilter]);

  const loadGraph = async () => {
    setLoading(true);
    try {
      const data = await getKnowledgeGraph(fabricId);
      setGraph(data);
    } catch (err) {
      console.error("Failed to load knowledge graph", err);
    } finally {
      setLoading(false);
    }
  };

  const handleNodeClick = async (nodeId: string) => {
    try {
      const details = await getNodeDetails(fabricId, nodeId);
      setSelectedNode(details);
    } catch (err) {
      console.error("Failed to load node details", err);
    }
  };

  const drawGraph = () => {
    if (!canvasRef.current || !graph) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Filter nodes based on selection
    let filteredNodes = graph.nodes;
    if (nodeFilter !== "all") {
      filteredNodes = graph.nodes.filter((n) => n.nodeType === nodeFilter);
    }

    if (filteredNodes.length === 0) return;

    // Simple force-directed layout (circular for simplicity)
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(canvas.width, canvas.height) * 0.35;

    const positions: Record<string, { x: number; y: number }> = {};
    filteredNodes.forEach((node, i) => {
      const angle = (i / filteredNodes.length) * 2 * Math.PI;
      positions[node.id] = {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      };
    });

    // Draw edges
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 1;
    graph.edges.forEach((edge) => {
      const source = positions[edge.sourceNodeId];
      const target = positions[edge.targetNodeId];
      if (source && target) {
        ctx.beginPath();
        ctx.moveTo(source.x, source.y);
        ctx.lineTo(target.x, target.y);
        ctx.stroke();
      }
    });

    // Draw nodes
    filteredNodes.forEach((node) => {
      const pos = positions[node.id];
      if (!pos) return;

      // Node color based on type
      let color = "#3b82f6"; // blue
      if (node.nodeType === "incident") color = "#ef4444"; // red
      else if (node.nodeType === "kb_article") color = "#10b981"; // green
      else if (node.nodeType === "category") color = "#8b5cf6"; // purple
      else if (node.nodeType === "error_code") color = "#f59e0b"; // orange

      // Draw circle
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 8, 0, 2 * Math.PI);
      ctx.fill();

      // Draw label
      ctx.fillStyle = "#e2e8f0";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(node.label.substring(0, 15), pos.x, pos.y + 20);
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!graph || graph.nodes.length === 0) {
    return (
      <EmptyState
        icon={<CubeTransparentIcon className="w-16 h-16" />}
        title="No Knowledge Graph"
        message="Knowledge graph will be generated after fabric build completes."
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <div className="text-sm text-slate-400">Total Nodes</div>
          <div className="text-2xl font-bold text-slate-100">{graph.stats.nodeCount}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Total Edges</div>
          <div className="text-2xl font-bold text-slate-100">{graph.stats.edgeCount}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Node Types</div>
          <div className="text-2xl font-bold text-slate-100">
            {new Set(graph.nodes.map((n) => n.nodeType)).size}
          </div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Avg Connections</div>
          <div className="text-2xl font-bold text-slate-100">
            {(graph.stats.edgeCount / graph.stats.nodeCount).toFixed(1)}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex items-center space-x-2">
          <span className="text-sm text-slate-400">Filter by type:</span>
          <select
            value={nodeFilter}
            onChange={(e) => setNodeFilter(e.target.value)}
            className="px-3 py-1 bg-slate-700 border border-slate-600 rounded text-slate-100 text-sm"
          >
            <option value="all">All Nodes</option>
            <option value="incident">Incidents</option>
            <option value="kb_article">KB Articles</option>
            <option value="category">Categories</option>
            <option value="error_code">Error Codes</option>
          </select>
        </div>
      </div>

      {/* Graph Visualization */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold text-slate-100 mb-4">
          Knowledge Graph Visualization
        </h3>
        <div className="relative bg-slate-900 rounded-lg overflow-hidden" style={{ height: "500px" }}>
          <canvas
            ref={canvasRef}
            className="w-full h-full cursor-pointer"
            onClick={(e) => {
              // Simple click detection (can be improved)
              console.log("Canvas clicked", e);
            }}
          />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span className="text-xs text-slate-400">Incidents</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-xs text-slate-400">KB Articles</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-purple-500"></div>
            <span className="text-xs text-slate-400">Categories</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
            <span className="text-xs text-slate-400">Error Codes</span>
          </div>
        </div>
      </div>

      {/* Node List */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold text-slate-100 mb-4">Nodes</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {graph.nodes
            .filter((n) => nodeFilter === "all" || n.nodeType === nodeFilter)
            .map((node) => (
              <div
                key={node.id}
                className="flex items-center justify-between p-2 bg-slate-800 rounded hover:bg-slate-750 cursor-pointer transition-colors"
                onClick={() => handleNodeClick(node.nodeId)}
              >
                <div className="flex items-center space-x-2">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      node.nodeType === "incident"
                        ? "bg-red-500"
                        : node.nodeType === "kb_article"
                        ? "bg-green-500"
                        : node.nodeType === "category"
                        ? "bg-purple-500"
                        : "bg-orange-500"
                    }`}
                  ></span>
                  <span className="text-sm text-slate-200">{node.label}</span>
                </div>
                <span className="text-xs text-slate-500">{node.nodeType}</span>
              </div>
            ))}
        </div>
      </div>

      {/* Node Details Modal */}
      {selectedNode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-slate-800 rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-100">
                {selectedNode.node.label}
              </h3>
              <button
                onClick={() => setSelectedNode(null)}
                className="text-slate-400 hover:text-white"
              >
                <XMarkIcon className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <div className="text-sm text-slate-400">Node ID:</div>
                <div className="text-slate-200">{selectedNode.node.nodeId}</div>
              </div>

              <div>
                <div className="text-sm text-slate-400">Type:</div>
                <div className="text-slate-200">{selectedNode.node.nodeType}</div>
              </div>

              {selectedNode.node.properties && Object.keys(selectedNode.node.properties).length > 0 && (
                <div>
                  <div className="text-sm text-slate-400 mb-2">Properties:</div>
                  <div className="bg-slate-900 p-3 rounded text-xs font-mono text-slate-300">
                    <pre>{JSON.stringify(selectedNode.node.properties, null, 2)}</pre>
                  </div>
                </div>
              )}

              <div>
                <div className="text-sm text-slate-400 mb-2">
                  Outgoing Relationships ({selectedNode.outgoingEdges.length}):
                </div>
                <div className="space-y-1">
                  {selectedNode.outgoingEdges.map((edge) => (
                    <div key={edge.id} className="text-sm text-slate-300 bg-slate-900 p-2 rounded">
                      → {edge.relationshipType}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-sm text-slate-400 mb-2">
                  Incoming Relationships ({selectedNode.incomingEdges.length}):
                </div>
                <div className="space-y-1">
                  {selectedNode.incomingEdges.map((edge) => (
                    <div key={edge.id} className="text-sm text-slate-300 bg-slate-900 p-2 rounded">
                      ← {edge.relationshipType}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-sm text-slate-400 mb-2">
                  Connected Nodes ({selectedNode.connectedNodes.length}):
                </div>
                <div className="space-y-1">
                  {selectedNode.connectedNodes.map((node) => (
                    <div
                      key={node.id}
                      className="text-sm text-slate-300 bg-slate-900 p-2 rounded cursor-pointer hover:bg-slate-800"
                      onClick={() => handleNodeClick(node.nodeId)}
                    >
                      {node.label} ({node.nodeType})
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import os
import threading
import chromadb
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
from sqlalchemy import func

from config import Config
from models import db, Fabric, IngestionHistory, FabricDocument, GraphNode, GraphEdge
from services.ingestion import process_fabric_build
from services.agent import ChatAgent

app = Flask(__name__)
app.config.from_object(Config)
CORS(app)
db.init_app(app)

# Ensure tables exist
with app.app_context():
    db.create_all()

# ============= FABRIC ROUTES =============

@app.route('/api/fabrics', methods=['GET'])
def get_fabrics():
    """Get all fabrics with optional filtering"""
    # Get query parameters
    source_type = request.args.get('sourceType')  # 'uploads', 'servicenow', 'sharepoint'
    status = request.args.get('status')
    
    query = Fabric.query
    
    # Apply filters
    if status:
        query = query.filter_by(status=status)
    
    fabrics = query.all()
    
    # Filter by source type if specified
    if source_type:
        fabrics = [f for f in fabrics if f.source_breakdown.get(source_type, 0) > 0]
    
    return jsonify([f.to_dict() for f in fabrics])


@app.route('/api/fabrics/<id>', methods=['GET'])
def get_fabric(id):
    """Get fabric by ID with optional detailed stats"""
    fabric = Fabric.query.get_or_404(id)
    include_stats = request.args.get('includeStats', 'true').lower() == 'true'
    
    result = fabric.to_dict()
    
    if include_stats:
        # Add real-time ChromaDB count
        try:
            collection_name = fabric.rag_config.get('chromaCollection')
            chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
            collection = chroma_client.get_collection(collection_name)
            actual_chunks = collection.count()
            result['actualChunksInDB'] = actual_chunks
            result['chunksMatch'] = actual_chunks == fabric.chunks_count
        except:
            result['actualChunksInDB'] = 0
            result['chunksMatch'] = False
    
    return jsonify(result)


@app.route('/api/fabrics', methods=['POST'])
def create_fabric():
    """Create new fabric"""
    data = request.json
    
    new_fabric = Fabric(
        name=data['name'],
        description=data.get('description', ''),
        domain=data['domain'],
        sources_config=data['sources'],
        rag_config={
            'chunkSize': data['chunkSize'],
            'chunkOverlap': data['chunkOverlap'],
            'embeddingModel': data['embeddingModel'],
            'chromaCollection': data['chromaCollection']
        },
        ingestion_stats={},
        source_breakdown={}
    )
    
    db.session.add(new_fabric)
    db.session.commit()
    
    # Create upload directory
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, new_fabric.id)
    if not os.path.exists(fabric_dir):
        os.makedirs(fabric_dir)
    
    return jsonify(new_fabric.to_dict()), 201


@app.route('/api/fabrics/<id>/build', methods=['POST'])
def trigger_build(id):
    """Trigger fabric build in background"""
    fabric = Fabric.query.get_or_404(id)
    
    # Start background thread
    thread = threading.Thread(
        target=process_fabric_build,
        args=(id, app)
    )
    thread.start()
    
    return jsonify({
        "status": "Ingesting",
        "message": "Build started"
    })


@app.route('/api/fabrics/<id>/upload', methods=['POST'])
def upload_documents(id):
    """Upload documents to fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    if 'files' not in request.files:
        return jsonify({"error": "No files provided"}), 400
    
    files = request.files.getlist('files')
    uploaded_files = []
    
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, id)
    if not os.path.exists(fabric_dir):
        os.makedirs(fabric_dir)
    
    for file in files:
        if file and file.filename:
            filename = secure_filename(file.filename)
            filepath = os.path.join(fabric_dir, filename)
            file.save(filepath)
            uploaded_files.append(filename)
    
    # Update fabric sources
    sources = fabric.sources_config
    if 'uploads' not in sources:
        sources['uploads'] = {}
    sources['uploads']['fileNames'] = uploaded_files
    fabric.sources_config = sources
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": f"Uploaded {len(uploaded_files)} files",
        "files": uploaded_files
    })


@app.route('/api/fabrics/<id>', methods=['DELETE'])
def delete_fabric(id):
    """Delete fabric and all related data"""
    fabric = Fabric.query.get_or_404(id)
    
    # Delete related records
    IngestionHistory.query.filter_by(fabric_id=id).delete()
    FabricDocument.query.filter_by(fabric_id=id).delete()
    GraphNode.query.filter_by(fabric_id=id).delete()
    GraphEdge.query.filter_by(fabric_id=id).delete()
    
    # Delete ChromaDB collection
    try:
        collection_name = fabric.rag_config.get('chromaCollection')
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        chroma_client.delete_collection(collection_name)
    except:
        pass
    
    # Delete uploaded files
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, id)
    if os.path.exists(fabric_dir):
        import shutil
        shutil.rmtree(fabric_dir)
    
    # Delete fabric
    db.session.delete(fabric)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Fabric deleted"
    })


# ============= DETAILED STATS ROUTES =============

@app.route('/api/fabrics/<id>/detailed-stats', methods=['GET'])
def get_detailed_stats(id):
    """Get comprehensive statistics for a fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get real-time ChromaDB count
    try:
        collection_name = fabric.rag_config.get('chromaCollection')
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        collection = chroma_client.get_collection(collection_name)
        actual_chunks = collection.count()
    except:
        actual_chunks = 0
    
    # Get file breakdown
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    
    return jsonify({
        "stored": {
            "documentsCount": fabric.documents_count,
            "chunksCount": fabric.chunks_count,
            "graphNodes": fabric.graph_nodes,
            "graphEdges": fabric.graph_edges,
            "ingestionStats": fabric.ingestion_stats or {},
            "sourceBreakdown": fabric.source_breakdown or {}
        },
        "realtime": {
            "chunksInChromaDB": actual_chunks,
            "matchesStored": actual_chunks == fabric.chunks_count
        },
        "files": [doc.to_dict() for doc in fabric_docs]
    })


@app.route('/api/fabrics/<id>/source-breakdown', methods=['GET'])
def get_source_breakdown(id):
    """Get breakdown by source type"""
    fabric = Fabric.query.get_or_404(id)
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    
    breakdown = {
        "uploads": {
            "count": 0,
            "documents": 0,
            "chunks": 0,
            "files": []
        },
        "servicenow": {
            "count": 0,
            "documents": 0,
            "chunks": 0,
            "tables": []
        }
    }
    
    for doc in fabric_docs:
        if doc.source_type == 'upload':
            breakdown["uploads"]["count"] += 1
            breakdown["uploads"]["documents"] += doc.document_count
            breakdown["uploads"]["chunks"] += doc.chunk_count
            breakdown["uploads"]["files"].append(doc.to_dict())
        elif doc.source_type.startswith('servicenow_'):
            breakdown["servicenow"]["count"] += 1
            breakdown["servicenow"]["documents"] += doc.document_count
            breakdown["servicenow"]["chunks"] += doc.chunk_count
            breakdown["servicenow"]["tables"].append(doc.to_dict())
    
    return jsonify(breakdown)


@app.route('/api/fabrics/<id>/files', methods=['GET'])
def get_fabric_files(id):
    """List all files in the fabric"""
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    return jsonify([doc.to_dict() for doc in fabric_docs])


# ============= INGESTION HISTORY ROUTES =============

@app.route('/api/fabrics/<id>/ingestion-history', methods=['GET'])
def get_ingestion_history(id):
    """Get ingestion history for a fabric"""
    history = IngestionHistory.query.filter_by(fabric_id=id).order_by(
        IngestionHistory.started_at.desc()
    ).all()
    
    return jsonify([record.to_dict() for record in history])


@app.route('/api/ingestion-history/<history_id>', methods=['GET'])
def get_ingestion_record(history_id):
    """Get specific ingestion history record"""
    record = IngestionHistory.query.get_or_404(history_id)
    return jsonify(record.to_dict())


# ============= KNOWLEDGE GRAPH ROUTES =============

@app.route('/api/fabrics/<id>/graph', methods=['GET'])
def get_knowledge_graph(id):
    """Get knowledge graph for a fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get all nodes
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    
    # Get all edges
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    return jsonify({
        "nodes": [node.to_dict() for node in nodes],
        "edges": [edge.to_dict() for edge in edges],
        "stats": {
            "nodeCount": len(nodes),
            "edgeCount": len(edges)
        }
    })


@app.route('/api/fabrics/<id>/graph/nodes', methods=['GET'])
def get_graph_nodes(id):
    """Get graph nodes with optional filtering"""
    node_type = request.args.get('type')
    
    query = GraphNode.query.filter_by(fabric_id=id)
    
    if node_type:
        query = query.filter_by(node_type=node_type)
    
    nodes = query.all()
    return jsonify([node.to_dict() for node in nodes])


@app.route('/api/fabrics/<id>/graph/node/<node_id>', methods=['GET'])
def get_node_details(id, node_id):
    """Get details for a specific node including its connections"""
    node = GraphNode.query.filter_by(fabric_id=id, node_id=node_id).first_or_404()
    
    # Get outgoing edges
    outgoing = GraphEdge.query.filter_by(fabric_id=id, source_node_id=node.id).all()
    
    # Get incoming edges
    incoming = GraphEdge.query.filter_by(fabric_id=id, target_node_id=node.id).all()
    
    # Get connected nodes
    connected_node_ids = set()
    for edge in outgoing:
        connected_node_ids.add(edge.target_node_id)
    for edge in incoming:
        connected_node_ids.add(edge.source_node_id)
    
    connected_nodes = GraphNode.query.filter(GraphNode.id.in_(connected_node_ids)).all()
    
    return jsonify({
        "node": node.to_dict(),
        "outgoingEdges": [edge.to_dict() for edge in outgoing],
        "incomingEdges": [edge.to_dict() for edge in incoming],
        "connectedNodes": [n.to_dict() for n in connected_nodes]
    })


@app.route('/api/fabrics/<id>/graph/search', methods=['GET'])
def search_graph(id):
    """Search nodes in the graph"""
    query_text = request.args.get('q', '')
    node_type = request.args.get('type')
    
    query = GraphNode.query.filter_by(fabric_id=id)
    
    if node_type:
        query = query.filter_by(node_type=node_type)
    
    if query_text:
        query = query.filter(
            db.or_(
                GraphNode.node_id.contains(query_text),
                GraphNode.label.contains(query_text)
            )
        )
    
    nodes = query.limit(50).all()
    return jsonify([node.to_dict() for node in nodes])


# ============= ANALYTICS ROUTES =============

@app.route('/api/analytics/dashboard', methods=['GET'])
def get_analytics_dashboard():
    """Get aggregate analytics across all fabrics"""
    
    # Total counts
    total_fabrics = Fabric.query.count()
    total_documents = db.session.query(func.sum(Fabric.documents_count)).scalar() or 0
    total_chunks = db.session.query(func.sum(Fabric.chunks_count)).scalar() or 0
    total_graph_nodes = db.session.query(func.sum(Fabric.graph_nodes)).scalar() or 0
    
    # Fabrics by status
    status_counts = db.session.query(
        Fabric.status,
        func.count(Fabric.id)
    ).group_by(Fabric.status).all()
    
    fabrics_by_status = {status: count for status, count in status_counts}
    
    # Recent fabrics
    recent_fabrics = Fabric.query.order_by(
        Fabric.created_at.desc()
    ).limit(5).all()
    
    # Source type distribution
    fabrics = Fabric.query.all()
    source_distribution = {
        "uploads": 0,
        "servicenow": 0,
        "sharepoint": 0
    }
    
    for fabric in fabrics:
        breakdown = fabric.source_breakdown or {}
        for source_type, count in breakdown.items():
            if count > 0:
                source_distribution[source_type] += 1
    
    # Recent ingestion attempts
    recent_ingestions = IngestionHistory.query.order_by(
        IngestionHistory.started_at.desc()
    ).limit(10).all()
    
    # Success rate
    total_ingestions = IngestionHistory.query.count()
    successful_ingestions = IngestionHistory.query.filter_by(status='completed').count()
    success_rate = (successful_ingestions / total_ingestions * 100) if total_ingestions > 0 else 0
    
    # Average ingestion time
    avg_duration = db.session.query(
        func.avg(IngestionHistory.duration_seconds)
    ).filter(
        IngestionHistory.status == 'completed'
    ).scalar() or 0
    
    return jsonify({
        "summary": {
            "totalFabrics": total_fabrics,
            "totalDocuments": int(total_documents),
            "totalChunks": int(total_chunks),
            "totalGraphNodes": int(total_graph_nodes),
            "fabricsByStatus": fabrics_by_status,
            "sourceDistribution": source_distribution
        },
        "ingestionMetrics": {
            "totalAttempts": total_ingestions,
            "successfulAttempts": successful_ingestions,
            "successRate": round(success_rate, 2),
            "avgDurationSeconds": int(avg_duration)
        },
        "recentFabrics": [f.to_dict() for f in recent_fabrics],
        "recentIngestions": [i.to_dict() for i in recent_ingestions]
    })


@app.route('/api/analytics/fabrics-over-time', methods=['GET'])
def get_fabrics_over_time():
    """Get fabric creation over time"""
    days = int(request.args.get('days', 30))
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    fabrics = Fabric.query.filter(
        Fabric.created_at >= start_date
    ).order_by(Fabric.created_at).all()
    
    # Group by date
    date_counts = {}
    for fabric in fabrics:
        date_key = fabric.created_at.strftime('%Y-%m-%d')
        date_counts[date_key] = date_counts.get(date_key, 0) + 1
    
    return jsonify({
        "data": [
            {"date": date, "count": count}
            for date, count in sorted(date_counts.items())
        ]
    })


@app.route('/api/analytics/source-breakdown', methods=['GET'])
def get_analytics_source_breakdown():
    """Get aggregate source breakdown across all fabrics"""
    fabrics = Fabric.query.all()
    
    total_by_source = {
        "uploads": {"fabrics": 0, "documents": 0, "chunks": 0},
        "servicenow": {"fabrics": 0, "documents": 0, "chunks": 0},
        "sharepoint": {"fabrics": 0, "documents": 0, "chunks": 0}
    }
    
    for fabric in fabrics:
        breakdown = fabric.source_breakdown or {}
        for source_type, doc_count in breakdown.items():
            if doc_count > 0:
                total_by_source[source_type]["fabrics"] += 1
                total_by_source[source_type]["documents"] += doc_count
    
    return jsonify(total_by_source)


# ============= CHAT ROUTES =============

@app.route('/api/chat', methods=['POST'])
def chat():
    """Process chat query"""
    data = request.json
    fabric_id = data.get('fabricId')
    messages = data.get('messages', [])
    
    fabric = Fabric.query.get(fabric_id)
    if not fabric:
        return jsonify({"error": "Fabric not found"}), 404
    
    if fabric.status != "Ready":
        return jsonify({"error": "Fabric not ready"}), 400
    
    collection_name = fabric.rag_config.get('chromaCollection')
    
    try:
        agent = ChatAgent(collection_name)
        result = agent.chat(messages[-1]['content'])
        
        return jsonify({
            "conversationId": "conv-1",
            "messages": messages + [{
                "role": "assistant",
                "content": result['answer'],
                "sources": result.get('sources', [])
            }]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ============= FEEDBACK ROUTES =============

@app.route('/api/feedback', methods=['POST'])
def submit_feedback():
    """Submit user feedback"""
    data = request.json
    print(f"Feedback received: {data}")
    return '', 204


# ============= CONNECTION TEST ROUTES =============

@app.route('/api/connections/servicenow/check-credentials', methods=['GET'])
def check_servicenow_credentials():
    """Check if ServiceNow credentials are configured"""
    configured = bool(Config.SERVICENOW_USER and Config.SERVICENOW_PASS)
    return jsonify({
        "configured": configured,
        "message": "Credentials configured" if configured else "Credentials not set"
    })


@app.route('/api/connections/servicenow/test', methods=['POST'])
def test_servicenow_connection():
    """Test ServiceNow connection"""
    data = request.json
    instance_url = data.get('instanceUrl')
    return jsonify({
        "success": True,
        "message": "Connection successful"
    })


@app.route('/api/connections/sharepoint/test', methods=['POST'])
def test_sharepoint_connection():
    """Test SharePoint connection"""
    data = request.json
    site_url = data.get('siteUrl')
    return jsonify({
        "success": True,
        "message": "Connection successful"
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=4000)
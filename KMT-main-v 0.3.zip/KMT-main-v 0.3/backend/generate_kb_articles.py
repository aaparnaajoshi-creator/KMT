"""
Generate Synthetic ServiceNow KB Article Data Files
Creates realistic KB article text files that can be uploaded via the UI
"""

from datetime import datetime

# Sample KB articles
KB_ARTICLES = [
    {
        "number": "KB0056789",
        "category": "VPN",
        "title": "How to Configure and Troubleshoot Corporate VPN",
        "short_description": "Complete guide for VPN setup, configuration, and troubleshooting common connection issues",
        "content": """
# VPN Configuration and Troubleshooting Guide

## Overview
This guide covers the setup and troubleshooting of the corporate VPN client for remote access.

## Prerequisites
- Windows 10/11 or macOS 10.15+
- Valid company credentials
- Active network connection

## Installation Steps

### Step 1: Download VPN Client
1. Navigate to ServicePortal at https://portal.company.com
2. Click on "Software Downloads"
3. Select "VPN Client v3.5" for your operating system
4. Download the installer

### Step 2: Install VPN Client
1. Run the installer as Administrator (Windows) or with sudo (macOS)
2. Accept the license agreement
3. Choose "Typical Installation"
4. Click Install
5. Restart computer when prompted

### Step 3: Configure VPN Connection
1. Launch VPN Client
2. Click "Add New Connection"
3. Enter the following details:
   - Connection Name: Corporate VPN
   - Server Address: vpn.company.com
   - Port: 443
   - Protocol: IKEv2
4. Enter your company username and password
5. Enable "Save Credentials" (optional)
6. Click "Connect"

## Troubleshooting Common Issues

### ERR_CONNECTION_TIMEOUT
**Symptoms**: VPN client shows "Connection timeout" error

**Solutions**:
1. Check if corporate firewall is blocking port 443
2. Temporarily disable antivirus and try connecting
3. Verify VPN server address is correct
4. Check if you're using VPN client v3.5 or later
5. Restart VPN service: `net stop "VPN Service" && net start "VPN Service"`

### ERR_AUTH_FAILED
**Symptoms**: Authentication fails with "Invalid credentials"

**Solutions**:
1. Verify your username (use username@company.com format)
2. Reset your password via https://password.company.com
3. Check if account is locked (contact IT if locked)
4. Ensure you're not using special characters in password that VPN client doesn't support
5. Try removing saved credentials and re-entering them

### VPN Disconnects Frequently
**Symptoms**: VPN connection drops every few minutes

**Solutions**:
1. Update VPN client to latest version
2. Check network stability (ping 8.8.8.8 -t)
3. Disable power saving on network adapter
4. Increase VPN timeout in settings (Settings > Advanced > Timeout: 3600)
5. Contact IT if issues persist - may need server-side configuration

## Advanced Configuration

### Split Tunneling
To access both company resources and internet directly:
1. Open VPN Client Settings
2. Navigate to Advanced > Routing
3. Enable "Use split tunneling"
4. Add company subnets: 10.0.0.0/8, 172.16.0.0/12

### Multi-Factor Authentication
VPN now supports MFA:
1. Enable MFA in Settings > Security
2. Choose method: SMS, Email, or Authenticator App
3. Complete enrollment process
4. On next login, enter MFA code when prompted

## Performance Tips
- Use wired connection instead of WiFi when possible
- Close bandwidth-intensive applications while on VPN
- Connect to geographically closest VPN gateway
- Disconnect VPN when not accessing company resources

## Related Articles
- KB0056790: Password Reset Procedures
- KB0056791: Email Configuration Guide
- KB0056801: Network Troubleshooting

## Support
For additional assistance, contact IT Support:
- Email: itsupport@company.com
- Phone: (555) 123-4567
- Portal: https://support.company.com

Last Updated: December 2025
"""
    },
    {
        "number": "KB0056790",
        "category": "Password",
        "title": "Password Reset and Account Security Best Practices",
        "short_description": "Guidelines for password management, self-service reset, and account security",
        "content": """
# Password Reset and Account Security Guide

## Password Policy
All company passwords must meet these requirements:
- Minimum 12 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number
- At least one special character (!@#$%^&*)
- Cannot reuse last 5 passwords
- Must be changed every 90 days

## Self-Service Password Reset

### Using the Password Portal
1. Navigate to https://password.company.com
2. Click "Forgot Password"
3. Enter your employee ID or company email
4. Choose verification method:
   - Email verification code
   - SMS verification code
   - Security questions
5. Enter verification code received
6. Create new password following policy
7. Confirm new password
8. System will send confirmation email

### Verification Methods Setup
To use self-service reset, you must configure verification methods:
1. Log in to https://account.company.com
2. Navigate to Security > Verification Methods
3. Add at least two methods:
   - Personal email address
   - Personal mobile number
   - Security questions (minimum 3)

## Account Lockout

### What Causes Lockout
Your account will be locked after:
- 5 consecutive failed password attempts
- Attempting to log in from suspicious location without MFA
- Password expired and not reset within 7 days

### How to Unlock

**Self-Service Unlock**:
1. Wait 30 minutes for automatic unlock
2. Use password reset portal to reset password

**IT Support Unlock**:
1. Call IT Support: (555) 123-4567
2. Verify your identity (employee ID, manager name, last 4 of SSN)
3. IT will unlock account immediately
4. Reset password via portal

## Multi-Factor Authentication (MFA)

### Enrolling in MFA
1. Log in to https://account.company.com
2. Navigate to Security > Multi-Factor Authentication
3. Choose MFA method:
   - Microsoft Authenticator (recommended)
   - SMS codes
   - Email codes
4. Follow enrollment wizard
5. Save backup codes in secure location

### Using MFA
After entering password, you'll be prompted for MFA:
1. Open authenticator app
2. Enter 6-digit code
3. Optional: Check "Trust this device for 30 days"
4. Click Verify

### MFA Troubleshooting
**Not receiving codes**:
- Check spam folder (email)
- Verify phone number is correct (SMS)
- Ensure authenticator app is synced
- Use backup codes if needed

**Lost authenticator device**:
- Contact IT Support immediately
- Verify identity
- Re-enroll MFA on new device

## Password Best Practices

### Creating Strong Passwords
- Use passphrases: "Coffee!Morning@2025"
- Avoid personal information (birthdays, names)
- Don't reuse passwords across sites
- Use password manager (LastPass, 1Password)

### Password Security
- Never share passwords with anyone (including IT)
- Don't write passwords on sticky notes
- Change password if suspicious activity detected
- Enable MFA on all accounts that support it
- Use different passwords for work and personal accounts

### What IT Will NEVER Do
IT Support will NEVER:
- Ask for your password via email or phone
- Request password in a ticket
- Ask you to send password in any form
- Threaten account closure if you don't provide password

## Troubleshooting Common Issues

### ERROR_ACCESS_DENIED
**Cause**: Account locked or password incorrect
**Solution**: Reset password via portal or contact IT

### Cannot Access Password Portal (ERROR_FILE_NOT_FOUND)
**Cause**: Portal maintenance or certificate issue
**Solution**: Call IT Support for manual reset

### Password Doesn't Meet Requirements
**Cause**: Not following password policy
**Solution**: Review requirements above and try again

### "Password Recently Used"
**Cause**: Attempting to reuse old password
**Solution**: Choose different password

## Account Security Checklist
- [ ] Password meets all requirements
- [ ] MFA enabled on account
- [ ] Personal email verified
- [ ] Personal phone number verified
- [ ] Security questions answered
- [ ] Backup codes saved securely
- [ ] Password manager configured
- [ ] Reviewed account activity regularly

## Related Articles
- KB0056789: VPN Configuration Guide
- KB0056791: Email Setup Guide
- KB0056792: Account Security Training

## Support
For password-related assistance:
- Portal: https://password.company.com
- Email: itsupport@company.com
- Phone: (555) 123-4567
- Emergency (after hours): (555) 123-4568

Last Updated: December 2025
"""
    },
    {
        "number": "KB0056791",
        "category": "Email",
        "title": "Email Configuration and Troubleshooting Guide",
        "short_description": "Complete email setup instructions and solutions for common email issues",
        "content": """
# Corporate Email Configuration Guide

## Supported Email Clients
- Outlook (Windows/Mac) - Recommended
- Apple Mail (macOS/iOS)
- Gmail App (Android/iOS)
- Thunderbird
- Web Browser (webmail.company.com)

## Outlook Configuration (Office 365)

### Automatic Configuration
1. Open Outlook
2. Go to File > Add Account
3. Enter your email: yourname@company.com
4. Outlook will auto-detect settings
5. Enter password when prompted
6. Click Finish

### Manual Configuration
If automatic setup fails:
1. Go to File > Add Account > Manual Setup
2. Choose "Office 365"
3. Email: yourname@company.com
4. Password: Your company password
5. Exchange Server: outlook.office365.com
6. Test account settings
7. Click Next to complete

### Outlook Profile Issues
If experiencing persistent issues:
1. Close Outlook completely
2. Open Control Panel > Mail
3. Click "Show Profiles"
4. Remove old profile
5. Create new profile
6. Restart Outlook

## Mobile Device Setup

### iOS (iPhone/iPad)
1. Open Settings > Mail > Accounts
2. Tap "Add Account" > "Exchange"
3. Enter email and description
4. Choose "Configure Manually"
5. Server: outlook.office365.com
6. Enter username and password
7. Enable Mail, Contacts, Calendars
8. Save

### Android
1. Open Gmail app or Email app
2. Add Account > Exchange
3. Email: yourname@company.com
4. Server: outlook.office365.com
5. Domain\\Username: company\\yourname
6. Password: Your password
7. Choose sync options
8. Done

## Common Email Issues

### Emails Stuck in Outbox

**Symptoms**: Emails won't send, stay in Outbox

**Solutions**:
1. Check internet connection
2. Verify email size < 25MB (attachments)
3. Delete and recreate stuck email
4. Restart Outlook
5. Check if account is over quota
6. Recreate Outlook profile if problem persists

### Cannot Receive Emails

**Symptoms**: Not receiving new emails

**Solutions**:
1. Check junk/spam folder
2. Verify mailbox not full (check quota)
3. Test with Send/Receive button
4. Check email rules aren't moving messages
5. Verify email forwarding not configured
6. Contact IT if issue continues

### Emails Going to Spam

**For Senders**:
1. Ensure SPF record configured correctly
2. Add recipients to contacts
3. Ask recipients to mark as "Not Spam"
4. Avoid spam trigger words in subject
5. Don't send mass emails without approval

**For Recipients**:
1. Check spam folder regularly
2. Mark legitimate emails as "Not Spam"
3. Add sender to Safe Senders list
4. Create inbox rule for important senders

### Outlook Running Slowly

**Solutions**:
1. Archive old emails (keep inbox < 5000 items)
2. Empty Deleted Items folder
3. Disable unnecessary add-ins
4. Compact OST file
5. Increase cache size: File > Account Settings > Account Settings > Change > More Settings > Advanced > Outlook Data File Settings

## Email Best Practices

### Organization
- Use folders to categorize emails
- Set up rules for automatic sorting
- Archive emails older than 1 year
- Keep inbox under 5000 items
- Use search instead of endless scrolling

### Security
- Don't click links in suspicious emails
- Verify sender before opening attachments
- Report phishing to phishing@company.com
- Never send passwords via email
- Use encryption for sensitive data

### Professional Communication
- Use clear subject lines
- Keep emails concise and professional
- Reply within 24 business hours
- Use appropriate greetings and signatures
- Proofread before sending

## Email Signatures

### Creating Signature
1. Outlook > File > Options > Mail > Signatures
2. Click "New"
3. Enter signature name
4. Create signature with:
   - Your full name
   - Job title
   - Department
   - Phone number
   - Company logo (optional)
5. Choose default signature for new emails and replies

### Signature Template
```
Best regards,
[Your Name]
[Job Title]
[Department]
Phone: (555) 123-4567
Email: yourname@company.com
Company Name | www.company.com
```

## Out of Office (OOO) Setup

1. Outlook > File > Automatic Replies
2. Select "Send automatic replies"
3. Set date range (optional)
4. Create message for internal and external contacts
5. Click OK

**OOO Message Template**:
"I am out of office with limited access to email from [start date] to [end date]. For urgent matters, please contact [colleague name] at [email] or call [phone]. I will respond to your email when I return."

## Email Quotas and Storage

- Mailbox Size Limit: 50GB
- Single Email Size: 25MB
- Attachment Total Size: 25MB per email
- Archive Storage: Unlimited

**Check Your Quota**:
1. Outlook > File > Account Settings
2. View "Mailbox Size"
3. If > 45GB, start archiving

## Troubleshooting Tools

### Test Email Connectivity
PowerShell command:
```
Test-NetConnection outlook.office365.com -Port 443
```

### Outlook Safe Mode
Start Outlook without add-ins:
```
Windows Key + R > outlook.exe /safe
```

### Support Response Tool (SaRA)
Download from: https://aka.ms/SaRA
- Automated diagnostics for Outlook issues
- Fixes common problems automatically

## Related Articles
- KB0056789: VPN Setup Guide
- KB0056790: Password Reset Guide
- KB0056795: Software Installation Guide
- KB0056803: Phishing Awareness Training

## Support
Email issues? Contact IT:
- Portal: https://support.company.com
- Email: itsupport@company.com
- Phone: (555) 123-4567

Last Updated: December 2025
"""
    },
    {
        "number": "KB0056795",
        "category": "Software",
        "title": "Software Installation and Troubleshooting Guide",
        "short_description": "Instructions for installing corporate software and resolving common installation issues",
        "content": """
# Corporate Software Installation Guide

## Accessing Software Catalog

### ServicePortal
1. Navigate to https://portal.company.com
2. Log in with company credentials
3. Click "Software Downloads"
4. Browse or search for software
5. Click "Download" or "Request Installation"

### Self-Service Options
Approved software can be installed without IT approval:
- Microsoft Office 365
- Web browsers (Chrome, Firefox, Edge)
- Adobe Reader
- VPN Client
- Collaboration tools (Teams, Zoom, Slack)

### Approval Required
Submit request for:
- Development tools (Visual Studio, IntelliJ)
- Design software (AutoCAD, Adobe Creative Suite)
- Specialized applications
- Software not in catalog

## Microsoft Office 365 Installation

### Installation Steps
1. Visit https://portal.office.com
2. Log in with company email
3. Click "Install Office" > "Office 365 apps"
4. Download installer
5. Run installer (requires admin rights)
6. Sign in when prompted
7. Office apps will download and install automatically

### Activation
Office should activate automatically. If not:
1. Open any Office app (Word, Excel)
2. Click "Activate"
3. Sign in with company email
4. Activation should complete

### Office Apps Included
- Word, Excel, PowerPoint
- Outlook, OneNote, Publisher
- Teams, OneDrive
- 1TB OneDrive storage
- Office apps on mobile devices (5 devices)

## Common Software Issues

### Installation Fails with ERROR_ACCESS_DENIED

**Cause**: Insufficient permissions

**Solutions**:
1. Right-click installer > "Run as administrator"
2. Contact IT for admin rights temporarily
3. Submit installation request via ServicePortal
4. Check if antivirus is blocking installation

### Software Won't Launch After Installation

**Symptoms**: Program installed but won't start

**Solutions**:
1. Restart computer
2. Check Windows Event Viewer for errors
3. Verify system requirements met
4. Run program as administrator
5. Reinstall software
6. Check antivirus exclusions

### Excel/Word Crashing (ERROR_MEMORY_LIMIT)

**Symptoms**: Office apps crash with large files

**Solutions**:
1. Close other applications to free RAM
2. Increase virtual memory:
   - System Properties > Advanced > Performance Settings
   - Advanced tab > Virtual Memory > Change
   - Set custom size (1.5x your RAM)
3. Disable hardware acceleration:
   - File > Options > Advanced
   - Display section > Disable hardware graphics acceleration
4. Clear Office cache:
   - Delete %LOCALAPPDATA%\\Microsoft\\Office\\16.0\\OfficeFileCache
5. Update to latest Office version

### License Errors

**Symptoms**: "License not found" or "Activation required"

**Solutions**:
1. Verify you're signed in with company account
2. Check internet connection
3. Reactivate Office:
   - File > Account > Update License
4. Clear Office license:
   ```
   cscript "C:\\Program Files\\Microsoft Office\\Office16\\OSPP.VBS" /dstatus
   cscript "C:\\Program Files\\Microsoft Office\\Office16\\OSPP.VBS" /act
   ```
5. Contact IT if issues persist

## Software Updates

### Windows Updates
Updates applied automatically:
- Security updates: Weekly
- Feature updates: Quarterly
- Updates install overnight when computer is idle

### Delaying Updates
If working on critical tasks:
1. Settings > Windows Update > Pause Updates
2. Maximum pause: 7 days
3. Resume updates when convenient

### Office Updates
Office updates automatically:
- Monthly updates
- Can update manually: File > Account > Update Options > Update Now

## Uninstalling Software

### Standard Uninstall
1. Settings > Apps > Apps & features
2. Find application
3. Click "Uninstall"
4. Follow wizard

### Complete Removal
Some apps leave files behind:
1. Uninstall normally
2. Delete leftover folders:
   - C:\\Program Files\\[App Name]
   - C:\\Program Files (x86)\\[App Name]
   - %APPDATA%\\[App Name]
   - %LOCALAPPDATA%\\[App Name]
3. Clean registry (advanced users only)

## Software Recommendations

### Productivity
- Microsoft Office 365 (Word, Excel, PowerPoint)
- Microsoft OneNote (Note-taking)
- Microsoft Teams (Collaboration)
- OneDrive (Cloud storage)

### Development
- Visual Studio Code (Code editor)
- Git (Version control)
- Postman (API testing)
- Docker Desktop (Containers)

### Browsers
- Microsoft Edge (Primary - corporate compliance)
- Google Chrome (Alternative)
- Mozilla Firefox (Alternative)

### Security
- Microsoft Defender (Antivirus - pre-installed)
- LastPass (Password manager)
- VPN Client (Remote access)

### Utilities
- 7-Zip (File compression)
- Adobe Reader (PDF viewing)
- Notepad++ (Text editor)
- VLC (Media player)

## Performance Optimization

### Keep Software Updated
- Enable automatic updates
- Check monthly for software updates
- Uninstall unused applications

### Manage Startup Programs
1. Task Manager > Startup tab
2. Disable unnecessary startup items
3. Improves boot time and performance

### Disk Cleanup
1. Search for "Disk Cleanup"
2. Select drive C:
3. Check all boxes
4. Click OK
5. Delete files

## Troubleshooting Tools

### System File Checker
Fix corrupted Windows files:
```
sfc /scannow
```

### DISM Tool
Repair Windows image:
```
DISM /Online /Cleanup-Image /RestoreHealth
```

### Event Viewer
Check for error logs:
1. Windows Key + X > Event Viewer
2. Windows Logs > Application
3. Look for Error and Warning events

## Related Articles
- KB0056789: VPN Configuration
- KB0056790: Password Management
- KB0056791: Email Setup
- KB0056801: Network Troubleshooting
- KB0056802: Performance Optimization

## Support
For software installation assistance:
- Portal: https://portal.company.com
- Email: itsupport@company.com
- Phone: (555) 123-4567
- Submit ticket: https://support.company.com/tickets

Last Updated: December 2025
"""
    },
    {
        "number": "KB0056801",
        "category": "Network",
        "title": "Network Connectivity Troubleshooting Guide",
        "short_description": "Diagnostic steps and solutions for network connectivity problems",
        "content": """
# Network Connectivity Troubleshooting

## Quick Diagnostics

### Check Physical Connection
1. Verify Ethernet cable plugged in (if wired)
2. Check for loose connections
3. Look for damaged cables
4. Verify link lights on network port
5. Try different cable if available

### Check Network Status
Windows:
1. Right-click network icon in taskbar
2. Click "Open Network & Internet settings"
3. Check connection status

macOS:
1. Click Apple menu > System Preferences
2. Select Network
3. Check connection status

## Common Network Issues

### ERR_NETWORK_UNREACHABLE

**Symptoms**: Cannot access any network resources

**Solutions**:
1. Restart network adapter:
   ```
   Windows: ipconfig /release && ipconfig /renew
   macOS: sudo ifconfig en0 down && sudo ifconfig en0 up
   ```
2. Renew DHCP lease
3. Check if IP address obtained (ipconfig or ifconfig)
4. Verify default gateway configured
5. Test with different network (switch WiFi to Ethernet)

### Intermittent Connectivity

**Symptoms**: Network drops randomly

**Solutions**:
1. Check WiFi signal strength (should be > -70 dBm)
2. Move closer to access point
3. Switch WiFi channels (if home network)
4. Disable power saving on network adapter:
   - Device Manager > Network adapters
   - Right-click adapter > Properties
   - Power Management > Uncheck "Allow computer to turn off device"
5. Update network drivers

### Cannot Connect to WiFi

**Symptoms**: WiFi network not showing or can't connect

**Solutions**:
1. Toggle WiFi off and on
2. Restart computer
3. Forget network and reconnect:
   - Windows: Settings > Network > WiFi > Manage known networks
   - macOS: System Preferences > Network > WiFi > Advanced
4. Check if MAC address is allowed (corporate WiFi)
5. Verify password is correct

### Slow Network Performance

**Symptoms**: Internet/network very slow

**Diagnostics**:
1. Test speed: https://speedtest.net
2. Expected speeds:
   - Ethernet: 900+ Mbps
   - WiFi 6: 300-600 Mbps
   - WiFi 5: 100-300 Mbps

**Solutions**:
1. Close bandwidth-intensive applications
2. Check if others on network experiencing issues
3. Restart router/switch
4. Check for network congestion (too many users)
5. Run malware scan (could be infected)
6. Clear DNS cache:
   ```
   ipconfig /flushdns
   ```

## Network Diagnostic Commands

### Windows Commands

**Check IP Configuration**:
```
ipconfig /all
```
Shows: IP address, subnet mask, default gateway, DNS servers

**Test Connectivity to Gateway**:
```
ping 10.0.0.1
```
Replace with your gateway IP

**Test DNS Resolution**:
```
nslookup google.com
```

**Trace Route to Destination**:
```
tracert google.com
```
Shows path packets take

**Reset Network Stack**:
```
netsh winsock reset
netsh int ip reset
ipconfig /flushdns
ipconfig /registerdns
```

### macOS/Linux Commands

**Check IP Configuration**:
```
ifconfig
```

**Test Connectivity**:
```
ping -c 4 8.8.8.8
```

**Test DNS**:
```
dig google.com
```

**Trace Route**:
```
traceroute google.com
```

**Flush DNS Cache**:
```
sudo dscacheutil -flushcache
sudo killall -HUP mDNSResponder
```

## Specific Network Issues

### ERR_DNS_LOOKUP Failed

**Symptoms**: Websites don't load, DNS errors

**Solutions**:
1. Use public DNS servers:
   - Primary: 8.8.8.8 (Google)
   - Secondary: 1.1.1.1 (Cloudflare)
2. Flush DNS cache (see commands above)
3. Restart DNS client service (Windows):
   ```
   net stop dnscache && net start dnscache
   ```

### ERR_CONNECTION_TIMEOUT

**Symptoms**: Connections time out

**Solutions**:
1. Check firewall not blocking connection
2. Verify server/website is up
3. Try connecting from different network
4. Check if port is blocked
5. Disable VPN temporarily to test

### Cannot Access File Shares

**Symptoms**: Cannot map network drives or access \\\\server\\share

**Solutions**:
1. Verify SMB services running:
   ```
   net use
   ```
2. Check network discovery enabled:
   - Settings > Network > Change advanced sharing settings
   - Enable network discovery and file sharing
3. Verify credentials:
   ```
   net use \\\\server\\share /user:domain\\username password
   ```
4. Check if firewall blocking SMB (port 445)

## Network Performance Optimization

### WiFi Optimization
1. Position closer to access point
2. Avoid physical obstructions (walls, metal)
3. Switch to 5GHz band if available
4. Update WiFi driver
5. Change WiFi channel (if home)

### Ethernet Optimization
1. Use Cat6 or better cables
2. Check cable not damaged
3. Verify link speed is 1Gbps:
   ```
   Windows: Network adapter properties > Link Speed
   macOS: Option + click WiFi icon
   ```
4. Update network driver

### Corporate Network
1. Connect via Ethernet in office (fastest)
2. Use VPN only when needed
3. Disconnect from VPN when not accessing corporate resources
4. Report network issues to IT immediately

## Firewall Issues

### Check Windows Firewall
1. Settings > Windows Security > Firewall & network protection
2. Check if blocking application
3. Add exception if needed:
   - Advanced settings > Inbound Rules > New Rule

### Corporate Firewall
If accessing external service:
1. Verify service is approved
2. Submit firewall request via ServicePortal
3. Provide: destination URL/IP, port, business justification
4. IT will review and approve/deny

## VPN Connectivity Issues

See KB0056789 for detailed VPN troubleshooting

**Quick checks**:
1. Verify VPN client updated
2. Check internet connection before connecting VPN
3. Try different VPN gateway
4. Disable split tunneling temporarily
5. Restart VPN service

## Network Security

### Best Practices
- Use encrypted WiFi (WPA3 or WPA2)
- Don't use public WiFi for sensitive work
- Always use VPN on untrusted networks
- Keep network drivers updated
- Report suspicious network activity

### Warning Signs
- Unexpected network slowdowns
- Cannot access certain websites
- Certificate warnings
- Network name changed
- Unexpected proxy settings

## Network Equipment

### Access Points
- Corporate AP prefix: "Corp-WiFi"
- Guest network: "Guest-WiFi"
- Coverage issues: Report to IT

### Ethernet Ports
- Office: All ports should provide 1Gbps
- Conference rooms: Check port labels
- Issues: Submit facilities ticket

## Related Articles
- KB0056789: VPN Configuration
- KB0056791: Email Troubleshooting
- KB0056802: Server Connectivity
- KB0056803: Security Best Practices

## Support
For network issues:
- Portal: https://support.company.com
- Email: network@company.com
- Phone: (555) 123-4567
- Emergency (network outage): (555) 123-4500

Last Updated: December 2025
"""
    }
]

def create_kb_articles_file(output_file="ServiceNow_KB_Articles.txt"):
    """Create a text file with KB articles"""
    
    print(f"🔄 Generating {len(KB_ARTICLES)} KB articles...")
    
    with open(output_file, 'w', encoding='utf-8') as f:
        # Header
        f.write("=" * 80 + "\n")
        f.write("SERVICENOW KNOWLEDGE BASE ARTICLES - SYNTHETIC DATA\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Articles: {len(KB_ARTICLES)}\n")
        f.write("=" * 80 + "\n\n")
        
        for kb in KB_ARTICLES:
            # Write KB article
            f.write("=" * 80 + "\n")
            f.write(f"KB ARTICLE: {kb['number']}\n")
            f.write(f"CATEGORY: {kb['category']}\n")
            f.write(f"TITLE: {kb['title']}\n")
            f.write(f"SHORT DESCRIPTION: {kb['short_description']}\n")
            f.write(f"PUBLISHED: {datetime.now().strftime('%Y-%m-%d')}\n")
            f.write("=" * 80 + "\n\n")
            f.write(kb['content'])
            f.write("\n\n")
            
            print(f"   Generated KB article: {kb['number']}")
    
    print(f"\n✅ Successfully created {output_file}")
    print(f"   File contains {len(KB_ARTICLES)} KB articles")
    print(f"   File size: {round(os.path.getsize(output_file) / 1024, 2)} KB")

if __name__ == '__main__':
    import os
    import sys
    
    output_file = sys.argv[1] if len(sys.argv) > 1 else "ServiceNow_KB_Articles.txt"
    
    create_kb_articles_file(output_file)
    print(f"\n📁 Ready to upload! Use this file in your fabric creation wizard.")

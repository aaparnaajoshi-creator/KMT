#from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END
from typing import TypedDict, List
import chromadb
from langchain_chroma import Chroma
from config import Config


# Define State
class AgentState(TypedDict):
    question: str
    context: List[str]
    answer: str
    sources: List[dict]

class ChatAgent:
    def __init__(self, collection_name, model_name="gpt-4"):
        # 1. Setup Embeddings with OpenAI
        self.embeddings = OpenAIEmbeddings(
            model="text-embedding-3-large",
            openai_api_key=Config.OPENAI_API_KEY
        )
        
        # 2. Use PersistentClient with local path
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        
        self.vectorstore = Chroma(
            client=chroma_client,
            collection_name=collection_name,
            embedding_function=self.embeddings,
        )
        
        # 3. Setup LLM with OpenAI
        self.llm = ChatOpenAI(
            model=model_name, 
            temperature=0.7,
            openai_api_key=Config.OPENAI_API_KEY
        )
        self.retriever = self.vectorstore.as_retriever(search_kwargs={"k": 5})
    def retrieve(self, state: AgentState):
        """Retrieve documents from Vector DB"""
        question = state["question"]
        documents = self.retriever.invoke(question)
        
        # Extract content and metadata
        context = [doc.page_content for doc in documents]
        sources = []
        for doc in documents:
            meta = doc.metadata
            sources.append({
                "id": meta.get("source", "Unknown"),
                "title": os.path.basename(meta.get("source", "Doc")),
                "snippet": doc.page_content[:150] + "...",
                "link": "#" 
            })
            
        return {"context": context, "sources": sources}

    def generate(self, state: AgentState):
        """Generate answer using RAG"""
        context_str = "\n\n".join(state["context"])
        question = state["question"]
        
        template = """You are a ServiceOps expert assistant. 
        Use the following pieces of retrieved context to answer the user's question.
        If you don't know the answer, say that you don't know. 
        Keep the answer concise but helpful for IT operations.
        
        Context:
        {context}
        
        Question: {question}
        
        Answer:"""
        
        prompt = ChatPromptTemplate.from_template(template)
        chain = prompt | self.llm | StrOutputParser()
        
        response = chain.invoke({"context": context_str, "question": question})
        return {"answer": response}

    def get_workflow(self):
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("retrieve", self.retrieve)
        workflow.add_node("generate", self.generate)
        
        # Add edges
        workflow.set_entry_point("retrieve")
        workflow.add_edge("retrieve", "generate")
        workflow.add_edge("generate", END)
        
        return workflow.compile()
        
    def chat(self, user_input):
        app = self.get_workflow()
        inputs = {"question": user_input}
        result = app.invoke(inputs)
        return result

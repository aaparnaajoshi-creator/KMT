from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import JSON
from datetime import datetime
import uuid

db = SQLAlchemy()

def generate_uuid():
    return str(uuid.uuid4())

class Fabric(db.Model):
    __tablename__ = 'fabrics'

    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    domain = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default="Draft") 
    
    # Use generic JSON (works with SQLite)
    sources_config = db.Column(JSON, nullable=True, default={})
    rag_config = db.Column(JSON, nullable=True, default={})
    
    # Stats
    documents_count = db.Column(db.Integer, default=0)
    chunks_count = db.Column(db.Integer, default=0)
    graph_nodes = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "domain": self.domain,
            "status": self.status,
            "sources": self.sources_config,
            "ragConfig": self.rag_config,
            "createdAt": self.created_at.isoformat(),
            "updatedAt": self.updated_at.isoformat(),
            "documentsCount": self.documents_count,
            "chunksCount": self.chunks_count,
            "graphNodes": self.graph_nodes,
        }
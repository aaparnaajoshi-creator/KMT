import os
import requests
import chromadb
# REMOVE THIS LINE: from app import app 
from models import db, Fabric
from config import Config
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.documents import Document

# ... (fetch_servicenow_data function remains exactly the same) ...
def fetch_servicenow_data(instance, username, password, table, limit=100):
    # Copy the function code from the previous response here
    # (It does not need changes for local setup)
    if not instance or not username: return []
    url = f"{instance}/api/now/table/{table}"
    params = {'sysparm_limit': limit, 'sysparm_fields': 'number,short_description,description,close_notes,sys_created_on', 'sysparm_query': 'active=false^ORDERBYDESCsys_created_on'}
    try:
        response = requests.get(url, auth=(username, password), params=params)
        if response.status_code != 200: return []
        data = response.json().get('result', [])
        docs = []
        for record in data:
            page_content = f"Ticket: {record.get('number')}\nIssue: {record.get('short_description')}\nDescription: {record.get('description')}\nResolution: {record.get('close_notes')}"
            metadata = {"source": record.get('number'), "type": table, "created_at": record.get('sys_created_on')}
            docs.append(Document(page_content=page_content, metadata=metadata))
        return docs
    except Exception as e:
        print(f"Error: {e}")
        return []

def process_fabric_build(fabric_id):
    """Background task to run the RAG pipeline"""
    with app.app_context():
        fabric = Fabric.query.get(fabric_id)
        if not fabric:
            return

        try:
            # 1. UPDATE STATUS
            fabric.status = "Ingesting"
            db.session.commit()
            
            sources = fabric.sources_config
            rag_config = fabric.rag_config
            documents = []
            
            # 2. INGEST UPLOADS
            if sources.get('uploads') and sources['uploads'].get('fileNames'):
                for filename in sources['uploads']['fileNames']:
                    file_path = os.path.join(Config.UPLOAD_FOLDER, fabric_id, filename)
                    if os.path.exists(file_path):
                        if filename.endswith('.pdf'):
                            loader = PyPDFLoader(file_path)
                            documents.extend(loader.load())
                        elif filename.endswith('.txt'):
                            loader = TextLoader(file_path)
                            documents.extend(loader.load())

            # 3. INGEST SERVICENOW
            sn_config = sources.get('serviceNow')
            if sn_config and sn_config.get('enabled'):
                for table in sn_config.get('tables', []):
                    sn_docs = fetch_servicenow_data(sn_config['instanceUrl'], Config.SERVICENOW_USER, Config.SERVICENOW_PASS, table)
                    documents.extend(sn_docs)

            fabric.documents_count = len(documents)
            
            # 4. CHUNKING
            fabric.status = "Chunking"
            db.session.commit()
            
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=rag_config.get('chunkSize', 512),
                chunk_overlap=rag_config.get('chunkOverlap', 64)
            )
            splits = text_splitter.split_documents(documents)
            fabric.chunks_count = len(splits)

            # 5. VECTORIZING (The Main Change)
            fabric.status = "Vectorizing"
            db.session.commit()
            
            if splits:
                embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
                collection_name = rag_config.get('chromaCollection', f"fabric_{fabric_id}")
                
                # --- CHANGE: Use PersistentClient with local path ---
                chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
                
                # Delete existing collection if rebuilding
                try:
                    chroma_client.delete_collection(collection_name)
                except:
                    pass
                
                vectorstore = Chroma(
                    client=chroma_client,
                    collection_name=collection_name,
                    embedding_function=embeddings,
                )
                
                # Batch add
                batch_size = 50
                for i in range(0, len(splits), batch_size):
                    batch = splits[i:i+batch_size]
                    vectorstore.add_documents(documents=batch)
            
            # 6. FINISH
            fabric.status = "Ready"
            db.session.commit()
            print(f"Build complete for {fabric_id}")

        except Exception as e:
            print(f"Build failed: {e}")
            fabric.status = "Error"
            fabric.description = f"{fabric.description} -- Error: {str(e)}"
            db.session.commit()